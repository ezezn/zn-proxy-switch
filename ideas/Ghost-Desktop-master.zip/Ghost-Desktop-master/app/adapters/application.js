export { default } from 'ember-local-storage/adapters/adapter';
